<header>
  <h2><img src="images/employees.png" width="140" height="140">
  ABC Employees</h2>
</header>
