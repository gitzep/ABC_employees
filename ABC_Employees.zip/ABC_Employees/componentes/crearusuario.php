
<?php
  require "../conexion_db.php";

  if(!empty($_POST['email']) && !empty($_POST['password'])) {
    $sql = "INSERT INTO user (email, password, type_user) VALUES(:email, :password, :type_user)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email',$_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password',$password);
    $stmt->bindParam(':type_user',$_POST['type_user']);

    if($stmt->execute()){
      echo 1;
    }else{
      echo 0;
    }
}

?>
