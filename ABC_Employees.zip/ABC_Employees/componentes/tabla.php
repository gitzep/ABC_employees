<?php

  session_start();

  require "../conexion_db.php";


?>

<div class="row">
  <div class="col-sm-12 table-responsive">
    <table class="table table-hover table-condensed table-striped" id="table">

      <tr class="bg-secondary text-white">
        <th colspan="6">Manage Employees</th>
        <th class="bg-secondary">

        <?php if($_SESSION['type_user'] != '1'):?>
          <button type="button" class="btn btn-danger" style="display:none">
        <?php else: ?>
          <button type="button" class="btn btn-danger" id="eliminarVarios">
        <?php endif; ?>

            <span class="glyphicon glyphicon-minus-sign"></span> Eliminar
          </button>

          <?php if($_SESSION['type_user'] != '1'):?>
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalNuevo" style="display:none">
          <?php else: ?>
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalNuevo">
          <?php endif; ?>

            <span class="glyphicon glyphicon-plus-sign"></span> Agregar Nuevo Empleado
          </button>
        </th>
      </tr>
      <tr>
        <th style="display:none"></th>
        <th><input type="checkbox" name="" value=""></th>
        <th>Nombre</th>
        <th>Correo Electronico</th>
        <th>Direccion</th>
        <th>Telefono</th>
        <th>Puesto</th>
        <th>Acciones</th>
      </tr>

      <?php

        $sql="SELECT id, name, email, address, telephone, job FROM employee";
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();
        while($row = $stmt->fetch()){

            $datos = $row["id"]."||".$row["name"]."||".$row["email"]."||".$row["address"]."||".$row["telephone"]."||".$row["job"];
      ?>

      <tr>
        <td style="display:none"> <?php echo $row["id"] ?> </td>
        <td><input type="checkbox" name="casilla[]" value=" " ></td>
        <td> <?php echo $row["name"] ?> </td>
        <td> <?php echo $row["email"] ?> </td>
        <td> <?php echo $row["address"] ?> </td>
        <td> <?php echo $row["telephone"] ?> </td>
        <td> <?php echo $row["job"] ?> </td>
        <td>

        <?php if($_SESSION['type_user'] != '1'):?>
          <button class="btn" data-toggle="modal" data-target="#modalEdicion" style="display:none">
        <?php else: ?>
          <button class="btn" data-toggle="modal" data-target="#modalEdicion" onclick="cargardatos('<?php echo $datos ?>')">
        <?php endif; ?>

            <span class="glyphicon glyphicon-pencil" style="color:yellow"></span>
          </button>

          <?php if($_SESSION['type_user'] != '1'):?>
            <button class="btn" style="display:none">
          <?php else: ?>
            <button class="btn" onclick="ConfirmarEliminar('<?php echo $row["id"] ?>')">
          <?php endif; ?>

            <span class="glyphicon glyphicon-trash" style="color:red"></span>
          </button>
        </td>
      </tr>
    <?php } ?>
    </table>
  </div>
</div>


<link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/alertify.css">
<link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/themes/default.css">
<script src="librerias/jquery-3.5.1.min.js"></script>
<script src="js/funciones.js"></script>
<script type="text/javascript">

  $('#eliminarVarios').click(function(){
    var lista = [];

    $("tbody tr").each(function(){
      var itemOrden = {};
      var tds = $(this).find("td");
      itemOrden.id = tds.filter(":eq(0)").text();
      itemOrden.check = tds.find(":checkbox").prop("checked");

      lista.push(itemOrden);

    });


    $.each(lista, function(index, value){

      var id = value.id;
      var check = value.check;

      if(check == true){
        eliminarDatos(id);
      }

    });
  });

</script>
