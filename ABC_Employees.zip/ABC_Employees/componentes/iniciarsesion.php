
<?php

  session_start();

  require "../conexion_db.php";

  if(empty($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password, type_user FROM user WHERE email=:email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    if (is_array($results) && password_verify($_POST['password'], $results['password'])){
      $_SESSION['user_id'] = $results['id'];
      $_SESSION['email'] = $results['email'];
      $_SESSION['type_user'] = $results['type_user'];
      echo 1;
    }
    else{
      echo 2;
    }

  }

?>
