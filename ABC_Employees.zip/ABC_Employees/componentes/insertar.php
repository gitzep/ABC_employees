
<?php
  require "../conexion_db.php";

    $sql = "INSERT INTO employee (name, email, address, telephone, job) VALUES(:name, :email, :address, :telephone, :job)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name',$_POST['name']);
    $stmt->bindParam(':email',$_POST['email']);
    $stmt->bindParam(':address',$_POST['address']);
    $stmt->bindParam(':telephone',$_POST['telephone']);
    $stmt->bindParam(':job',$_POST['job']);

    if($stmt->execute()){
      echo 1;
    }else{
      echo 0;
    }

?>
