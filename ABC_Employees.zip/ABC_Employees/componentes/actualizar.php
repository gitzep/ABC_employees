<?php
  require "../conexion_db.php";

    $sql = "UPDATE employee SET name=:name, email=:email, address=:address, telephone=:telephone, job=:job WHERE id=:id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id',$_POST['id']);
    $stmt->bindParam(':name',$_POST['name']);
    $stmt->bindParam(':email',$_POST['email']);
    $stmt->bindParam(':address',$_POST['address']);
    $stmt->bindParam(':telephone',$_POST['telephone']);
    $stmt->bindParam(':job',$_POST['job']);
    if($stmt->execute()){
      echo 1;
    }else{
      echo 0;
    }
?>
