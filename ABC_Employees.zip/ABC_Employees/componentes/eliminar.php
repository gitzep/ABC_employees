<?php
  require "../conexion_db.php";

  $sql = "DELETE FROM employee WHERE id=:id";
  $stmt = $conn->prepare($sql);
  $stmt->bindParam(':id',$_POST['id']);

  if($stmt->execute()){
    echo 1;
  }else{
    echo 0;
  }

?>
