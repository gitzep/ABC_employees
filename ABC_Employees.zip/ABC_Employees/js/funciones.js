
function IniciarSesion(email,pass){

  var string = {"email" : email,
          "password" : pass};

  $.ajax({
    url: "componentes/iniciarsesion.php",
    type: "POST",
		data: string,

    success:function(response){
        if(response==1){
          location.replace("Manage_Employees.php");
          alertify.success("Sesión iniciada");
        }else{
          alertify.error("Fallo del servidor");
        }
    }
  });
}


function signup(email, password, type_user){

  var cad = {"email" : email,
          "password" : password,
          "type_user" : type_user};

  $.ajax({
    url: "componentes/crearusuario.php",
    type: "POST",
		data: cad,

    success:function(response){
        if(response==1){
          alertify.success("Usuario creado con exito");
        }else{
          alertify.error("Fallo del servidor");
        }
    }

  });
}


function insertarDatos(name, email, address, telephone, job){

  var cadena = {"name": name,
          "email" : email,
          "address" : address,
          "telephone" : telephone,
          "job" : job};

  $.ajax({
    url: "componentes/insertar.php",
    type: "POST",
		data: cadena,

    success:function(response){
        if(response==1){
          $('#tabla').load('componentes/tabla.php');
          alertify.success("Agregado con exito");
        }else{
          alertify.error("Fallo del servidor");
        }
    }

  });
}


function cargardatos(datos){

  d=datos.split('||');

  $('#idpersona').val(d[0]);
  $('#NameU').val(d[1]);
  $('#EmailU').val(d[2]);
  $('#AddressU').val(d[3]);
  $('#PhoneU').val(d[4]);
  $('#JobU').val(d[5]);
}


function actualizarDatos(){

  id = $('#idpersona').val();
  name = $('#NameU').val();
  email = $('#EmailU').val();
  address = $('#AddressU').val();
  telephone = $('#PhoneU').val();
  job = $('#JobU').val();

  var cadena = {"id": id,
                "name": name,
                "email" : email,
                "address" : address,
                "telephone" : telephone,
                "job" : job};

  $.ajax({
    url: "componentes/actualizar.php",
    type: "POST",
		data: cadena,

    success:function(response){
        if(response==1){
          $('#tabla').load('componentes/tabla.php');
          alertify.success("Actualizado con exito");
        }else{
          alertify.error("Fallo del servidor");
        }
    }

  });
}


function ConfirmarEliminar(id){
  alertify.confirm('Eliminar Datos', '¿Desea eliminar este registro?',
          function(){ eliminarDatos(id) },
          function(){ alertify.error('Cancel')});
}


function eliminarDatos(id){

  var cadena = {"id": id};

  $.ajax({
    url: "componentes/eliminar.php",
    type: "POST",
		data: cadena,

    success:function(response){
        if(response==1){
          $('#tabla').load('componentes/tabla.php');
          alertify.success("Eliminado con exito");
        }else{
          alertify.error("Fallo del servidor");
        }
    }
  });
}
