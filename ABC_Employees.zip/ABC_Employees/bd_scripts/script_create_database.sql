
create database abc_employees_database;
