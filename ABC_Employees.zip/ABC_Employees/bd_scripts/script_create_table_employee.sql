
USE abc_employees_database;

CREATE TABLE employee(
    id int auto_increment,
    name varchar(200) NOT NULL,
    email varchar(200) NOT NULL,
    address varchar(200) NOT NULL,
    telephone int(8) NOT NULL,
    job varchar(200) NOT NULL,
    primary key(id)
);
