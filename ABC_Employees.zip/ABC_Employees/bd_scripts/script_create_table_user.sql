
USE abc_employees_database;

CREATE TABLE user (
  id int auto_increment,
  email varchar(200) NOT NULL,
  password varchar(200) NOT NULL,
  type_user int(11) NOT NULL,
  primary key(id)
);
