
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/style.css"

    <link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/alertify.css">
    <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/themes/default.css">

    <script src="librerias/jquery-3.5.1.min.js"></script>
    <script src="js/funciones.js"></script>
    <script src="librerias/bootstrap/js/bootstrap.js"></script>
    <script src="librerias/alertifyjs/alertify.js"></script>
  </head>
  <body>

    <a href="/ABC_Employees"><img align="right" src="images/regresar.png" width="150" height="50"></a>
    <?php require 'partials/header.php' ?>

    <h2>Iniciar Sesion</h2>

    <form action="login.php" method="post">
      <input type="text" id="email" placeholder="Ingrese su correo electronico">
      <input type="password" id="password" placeholder="Ingrese su contraseña">
      <div>
        <input type="button" id="login" value="Enviar">
      </div>

    </form>
  </body>
</html>

<script type="text/javascript">
$(document).ready(function(){
  $('#login').click(function(){

    if($('#email').val()==""){
      alertify.error("Ingrese su email");
      return false;
    }else if($('#password').val()==""){
      alertify.error("Ingrese su contraseña");
      return false;
    }

    email=$('#email').val();
    pass=$('#password').val();
    IniciarSesion(email,pass);
  });
});
</script>
