<?php
	session_start();

	if(isset($_SESSION['user_id'])) {
		include 'logout.php';
	}

?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>ABC Employees</title>
		<link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/style.css"
	</head>
	<body>

		<?php require 'partials/header.php' ?>

			<h3><small>Por favor, inicie sesión o regístrese</small></h3>
			<a href="login.php"> <img src="images/login.png"> </a>
			<a href="signup.php"> <img src="images/signup.png"> </a>
	</body>
</html>
