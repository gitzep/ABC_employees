
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>SignUp</title
      <link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">
  		<link rel="stylesheet" href="assets/css/style.css"

      <link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/alertify.css">
      <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/themes/default.css">

      <script src="librerias/jquery-3.5.1.min.js"></script>
      <script src="js/funciones.js"></script>
      <script src="librerias/bootstrap/js/bootstrap.js"></script>
      <script src="librerias/alertifyjs/alertify.js"></script>
  </head>
  <body>

    <a href="/ABC_Employees"><img align="right" src="images/regresar.png" width="150" height="50"></a>
    <?php require 'partials/header.php' ?>

    <h1>Registro</h1>

    <form action="signup.php" method="post">
      <input type="text" id="email" name="email" placeholder="Ingrese su correo electronico">
      <input type="password" id="password" name="password" placeholder="ingrese su contraseña">
      <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirme su contraseña">

      <select class="type_user" id="type_user" name="type_user">
        <option value="">Seleccione tipo de usuario</option>
        <option value="1">Administrador</option>
        <option value="2">Empleado</option>
      </select>
      <div>
        <input type="button" id="signup" value="Enviar">
      </div>

    </form>

  </body>
</html>

<script type="text/javascript">
  $(document).ready(function(){
    $('#signup').click(function(){

      if($('#email').val()==""){
        alertify.error("Ingrese su email");
        return false;
      }else if($('#password').val()==""){
        alertify.error("Ingrese su contraseña");
        return false;
      }else if($('#confirm_password').val()==""){
        alertify.error("Confirme su contraseña");
        return false;
      }else if($('#type_user').val()==""){
        alertify.error("Seleccione tipo de usuario");
        return false;
      }

      if($('#password').val() != $('#confirm_password').val()){
        alertify.error("Contraseñas no coinciden");
        return false;
      }

      email=$('#email').val();
      password=$('#password').val();
      type_user=$('#type_user').val();
      signup(email, password, type_user);
    });
  });
</script>
